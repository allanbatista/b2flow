def execute():
    print("OK")