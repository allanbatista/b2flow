import pandas as pd
from io.b2w.b2flow import storage, jobs

logging.info("executing")

# gs://bucket-name/b2flow/team-name/project-name/dag-name/job-name/year/month/day/hour/timestamp/result.csv
with storage.open('result.csv', 'w+') as f:
    f.write('header1,header2')

# gs://bucket-name/b2flow/team-name/project-name/dag-name/job1/year/month/day/hour/timestamp/result.json
with jobs('job1').storage.open('result.json', 'rb') as f:
    df = pd.read_json(f)

print(df)